<?php
defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php wp_head(); ?>
	</head>
	<style>
		@font-face {
			font-family: "Neon80s";
			src: url("/wp-content/themes/acelerapele/fonts/Neon.ttf");
		}
		*{
		  font-family: Neon80s !important;
		}
		.woocommerce-MyAccount-content{
			padding-right: 60px;
		}
		.section-page-title{
			text-transform: uppercase;
		}
		#site-content{
			margin-top: 120px;
			min-height: 450px;
		}
		.qtd{
			font-size: 11px;
			color: #211304;
			font-weight: lighter;
			margin-left: 10px;
			min-height: 16px;
			min-width: 1px;
			margin-bottom: 30px;
		}
		.cart-count-{
			font-size: 10px;
		}
		header span.woocommerce-Price-amount.amount {
			font-size: 15px;	
		}

		.summary .fswp_installments_price.single {
    display: none;
}
		span.fswp_installment_prefix {
    display: block;
    text-align: left;
    padding-left: 10px;
    font-size: 11px;
    color: #211304;
}
		ul.products.columns-3 span.price {
			display: none !important;
		}
		p.price.fswp_calc {
			display: flex !important;
			align-items: center;
			flex-direction: column;
			align-items: flex-start;
		}
 		.agendar-online-btn{
			position: fixed;
			top: 325px;
			right: -50px;
			z-index: 10;
			background: #F8955E;
			border-radius: 0px 0px 5px 5px;
			border: 0;
			padding: 10px 10px;
			transform: rotate(90deg) translatex(-50%);
			width: 150px;
			height: 50px;
			text-align: center;
		}
		a .agendar-online-btn{
			color: #FFFFFF;
			font-size: 14px;
		} 
		.agendar-online-div a:hover{
			background: #F8955E;
			opacity: 1;
		}
		.header-actions-wrapper-mobile{
			display: none;
		}
		.logo-link:hover{
			opacity: 1;
		}

		@media(max-width:767px){
			.agendar-online-btn{
				display: none;
			}
			.header-actions-wrapper-mobile{
				display: flex;
				width: 100%;
				position: fixed;
				bottom: 0;
				left: 0;
				z-index: 10;
			}
			.header-actions-wrapper-mobile .shop-mobile{
				text-transform: uppercase;
				background: #58B76B;
				font-size: 14px;
				text-align: center;
				width: 50%;
				color: #ffffff;
				padding: 15px 0;
			}

			.header-actions-wrapper-mobile .agendar-mobile{
				text-transform: uppercase;
				background: #E1B261;
				color: #3C2300;
				font-size: 14px;
				text-align: center;
				width: 50%;
				padding: 15px 0;
			}
		}
	</style>
	<body <?php body_class(); ?>>
		<div class="site" id="page">
			<header class="header-wrapper">
				<div class="header-container-wrapper">				
					<div class="menu-wrapper">
						<div class="topbar-wrapper">
							<div class="container">
								<div class="topbar-content">
									<div class="units-wrapper">
										<div class="unit-item">
											<img src="/wp-content/uploads/2021/06/whatsapp.png">
											<span>SHOPPING CENTER RECIFE</span>
										</div>
									</div>
									<div class="mobile-unit">
										<img src="/wp-content/uploads/2021/06/whatsapp.png">
										<span>SHOPPING CENTER RECIFE</span>
									</div>
									<div class="header-actions-wrapper">
										<a href="/my-account">fazer login</a>
										<a href="/tratamentos" class="shop">comprar online</a>
									</div>
								</div>
							</div>
						</div>
						<div class="logo-wrapper">
							<a class="logo-link" href="/">
								<div class="logo-rectangle-wrapper">
									<img class="logo-img" src="/wp-content/uploads/2021/06/header-logo-2.png">
								</div>
								<div class="logo-circle-wrapper">
									<img class="logo-img" src="/wp-content/uploads/2021/08/logo-branca.png">
								</div>
							</a>
							<nav class="navbar navbar-dark mobile-menu-icon">
								<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
									<img class="menu-icon" src="/wp-content/uploads/2021/08/menu-1.png">
								</button>
							</nav>
						</div>
						<div class="collapse" id="navbarToggleExternalContent">
							<div style="padding: 52px 17px;">
								<div class="nav-area-mobile">
									<a href="/tratamentos" class="menu-link">Tratamentos</a>
									<a href="/unidades" class="menu-link">Unidades</a>
									<a href="/contato" class="menu-link">Contato</a>
								</div>
							</div>
						</div>
						<div class="nav-wrapper">
							<div class="container">
								<div class="nav-content">
									<div class="nav-area">
										<a href="/tratamentos" class="menu-link">Tratamentos</a>
										<a href="/unidades" class="menu-link">Unidades</a>
										<a href="/contato" class="menu-link">Contato</a>
									</div>
									<a class="header-cart"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>
			<div class="agendar-online-div">
			<a href="https://api.whatsapp.com/send?phone=5581992591924&text=Quero%20saber%20mais%20sobre%20os%20tratamentos%20da%20cl%C3%ADnica%20pele!">
 			<div class="agendar-online-btn">
				AGENDAR ONLINE
			</div></a>
			</div>
			<div class="header-actions-wrapper-mobile">
				<a href="/tratamentos" class="shop-mobile">comprar online</a>
				<a href="#" class="agendar-mobile">agendar</a>
			</div>