<?php get_header(); ?>
<?php $title = 'Confira seu carrinho';
echo do_shortcode('[simple_header image="/wp-content/uploads/2021/06/simple-header-bg.png" title="'. $title . '"]'); ?>

<section class="cart">
	<div class="container">
		<h4 class="cart-title">Carrinho</h4>
		<?php echo do_shortcode('[woocommerce_cart]'); ?>	
	</div>
</section>
<style>
	td.product-quantity {
		justify-content: center;
		display: flex;
	}
	.product-quantity input {
		border: none;
		text-align: center;
		background: transparent;
		width: 1.7rem;
		padding: 0;
	}
	.cart-title{
		color: black;
		font-size: 30px;
		margin-bottom: 60px;
	}
	.cart{
		padding: 45px 0 135px;
	}
	.cart-custom-wrapper {
		display: grid;
		grid-template-columns: 3fr 1fr;
		grid-column-gap: 90px;
	}
	.cart-custom-wrapper .cart_totals {
		width: 100% !important;
	}
	.cart-custom-wrapper a.checkout-button.button.alt.wc-forward {
		background: rgba(88, 183, 107, 1);
		font-size: 12px;
		font-weight: normal;
		text-transform: uppercase;
	}
	.cart-custom-wrapper table.shop_table.shop_table_responsive.cart.woocommerce-cart-form__contents {
		border: none;
		padding: 0;
	}
	.cart-custom-wrapper thead {
		display: none;
	}
	.cart-custom-wrapper tr.woocommerce-cart-form__cart-item.cart_item td {
		border-top: none !important;
	}
	.cart_totals h2 {
		font-size: 18px;
		border-bottom: 1px solid #707070;
		padding-bottom: 26px;

	}
	table.shop_table.shop_table_responsive {
		border: none;
	}
	.woocommerce-cart .cart-collaterals .cart_totals tr th, .woocommerce-cart .cart-collaterals .cart_totals tr td, .woocommerce table.shop_table td{
		border-top: 1px solid #707070;
	}
	.woocommerce table.shop_table tbody th {
		color: #000000;
		font-weight: normal;
		padding-left: 0;
		padding-top: 20px;
	}
	.cart_totals span.woocommerce-Price-amount.amount {
		color: #3C2300;
		font-weight: normal;
		font-size: 18px;
	}
	.cart_totals .cart-subtotal span.woocommerce-Price-amount.amount {
		font-size: 12px;
	}
	.cart-subtotal td, .order-total td{
		padding-top: 20px !important;
	}
	.actions > button.button {
		display: none;
	}
	.coupon {
		display: flex;
		padding-top: 40px;
		align-items: center;
	}
	td.actions {
		padding: 0px !important;
	}
	button.button {
		background: #EBE6DF !important;
		color: #9A866C !important;
		font-weight: normal !important;
		font-size: 12px !important;
		text-transform: uppercase;
		height: 100%;
		padding: 13px 35px 12px !important;
		border: 1px solid #EBE6DF !important;
	}

	input#coupon_code {
		border: 1px solid #9A866C;
		border-radius: 5px;
		width: 250px;
		margin-right: 10px;
	}
	td.product-remove {
		display: none;
	}
	td.product-thumbnail {
		display: flex;
		align-items: center;
		justify-content: center;
	}
	img.attachment-woocommerce_thumbnail.size-woocommerce_thumbnail {
		width: 100px !important;
		height: 90px !important;
		border-radius: 5px;
		object-fit: cover;
	}
	td.product-name a {
		color: #211304;
	}
	td.product-price, td.product-subtotal {
		font-size: 12px;
		color: #3C2300;
	}
	.woocommerce-page table.cart td.actions .coupon label {
		display: block;
		margin: 0;
		margin-right: 30px;
	}
	@media(max-width:767px){

		.cart-custom-wrapper {
			display: flex;
			flex-direction: column;
			grid-column-gap: 0px;
		}
		input#coupon_code{
			width: 100px;
		}
		.cart-collaterals{
			margin-top: 45px;
		}
		.cart-title{
			text-align: center;
			margin-bottom: 30px;
		}
		.quantity{
			display: flex;
			justify-content: flex-end;
		}
		.group-inputs{
			padding: 5px 0;
			max-width: 90px;
		}
		.woocommerce .quantity .qty{
			width: 1rem;
		}
		.cart-custom-wrapper a.checkout-button.button.alt.wc-forward{
			font-size: 16px;
		}
	}
</style>
<script>
	jQuery(function($){
		var timeout;
		$('.woocommerce').on('click', 'input.more-less', function(){
			var qtdBtn = $(this).parent().find('.qty');
			var signal = parseInt($(this).attr('data-signal'));
			qtdBtn.val(String(parseInt(Math.max(0,parseInt(qtdBtn.val()) + signal))));
			$("[name='update_cart']").attr('disabled',false);
			if ( timeout !== undefined ) {
				clearTimeout( timeout );
			}
			timeout = setTimeout(function() {
				$("[name='update_cart']").trigger("click");

			}, 1000 ); // 1 second delay, half a second (500) seems comfortable too
		});	
	})
</script>

<?php get_footer(); ?>