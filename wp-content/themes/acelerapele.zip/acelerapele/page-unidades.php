<?php get_header(); ?>
<style>
	@media(max-width:767px){
		#unidades{
			margin-bottom: 75px !important;	
		}			
		#unidades .container{
			justify-content: center;
			flex-direction: column;
		}
	}
	#unidades{
		margin-top: 45px;
		margin-bottom: 150px;
	}
	#unidades .container{
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
	}
</style>
<section id="banner-principal">
	<?php
	$img = get_field("banner_principal");
	$title = get_field("banner_titulo");
	echo do_shortcode('[simple_header image="'. $img . '" title="'. $title . '"]'); 
	?>
</section>
<section id="unidades">
	<div class="container">
		<?php if(have_rows("unidades")): while(have_rows("unidades")): the_row();?>
		<?php
			$title = get_sub_field("titulo");
			$infos = get_sub_field("informacoes");
			$mapa = get_sub_field("link_mapa");
			$zap = get_sub_field("link_whatsapp");
			$tel = get_sub_field("link_telefone");
			echo do_shortcode('[single_unidade title="'.$title.'" infos="'.$infos.'" zap="'.$zap.'" tel="'.$tel.'" mapa="'.$mapa.'"]'); 
		?>
		<?php endwhile; endif; ?>
	</div>
</section>
<?php echo do_shortcode('[agendar_visita]'); ?>
<?php
	$title = get_field("compre_seu_tratamento_titulo",23);
	$image = get_field("compre_seu_tratamento_imagem",23);
	$title_button = get_field("compre_seu_tratamento_titulo_botao",23);
	$link_button = get_field("compre_seu_tratamento_link_botao",23);
	echo do_shortcode('[banner image="'. $image . '" title="'. $title . '" title_button="'. $title_button . '" link_button="'. $link_button . '"]'); 
?>
<?php echo do_shortcode('[form_footer]'); ?>

<?php get_footer(); ?>