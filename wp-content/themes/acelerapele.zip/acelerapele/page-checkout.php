<?php get_header(); ?>
<?php $title = 'INFORMAÇÕES DE CHECKOUT';
echo do_shortcode('[simple_header image="/wp-content/uploads/2021/06/simple-header-bg.png" title="'. $title . '"]'); ?>
<div class="container custom-checkout">
	<h2 class="checkout-title">
		CHECKOUT
	</h2>
	<?php echo do_shortcode('[woocommerce_checkout]'); ?>
</div>
<style>
	.woocommerce-info {
		border: none;
		background: white;
		text-align: center;
	}
	.showcoupon{
		color: #58B76B;
	}
	.showcoupon:hover{
		color: #58B76B;
	}
	.woocommerce-info::before {
		display: none;
	}
	.custom-checkout{
		margin-top: 45px;
		margin-bottom: 100px;
	}
	.checkout-title{
		font-size: 30px;
		margin-bottom: 34px;
	}
	.custom-checkout form.checkout.woocommerce-checkout {
		display: grid;
		grid-template-columns: 3fr 2fr;
		grid-gap: 120px;
	}
	.custom-checkout .form-row {
		display: flex;
		flex-direction: column;
		margin-bottom: 23px !important;
	}
	.custom-checkout .form-row label {
		font-size: 14px;
		color: black;
		font-weight: 600;
		margin-bottom: 17px;
	}
	span.select2.select2-container.select2-container--default {
    height: 42px;
    display: flex;
    align-items: center;
}
	.custom-row-last{
		float: right;
		width: 47%;
		overflow: visible;
		clear: none !important;
	}
	.custom-row-first{
		float: left;
		width: 47%;
		overflow: visible;
		clear: none !important;
	}
	span.select2-selection.select2-selection--single {
    border: none;
}
	.custom-checkout .form-row input,.form-row select, textarea,span.select2.select2-container.select2-container--default {
		border: 1px solid #9A866C;
		border-radius: 5px;
		padding: 11px 15px;
		color: black;
		background: white;
	}
	.custom-checkout table.shop_table.woocommerce-checkout-review-order-table {
		border: none;
	}
	.custom-checkout table.shop_table.woocommerce-checkout-review-order-table thead{
		display: none;
	}
	.custom-checkout .woocommerce table.shop_table .cart_item td{
		border: none;
		padding: 0;
	}
	.custom-checkout td.product-total {
		display: flex;
		justify-content: flex-end;
	}
	.woocommerce-billing-fields > h3 {
		font-size: 18px;
		color: #000000;
		margin-bottom: 35px;
	}
	h3#order_review_heading {
		color: #000000;
		font-size: 18px;
		padding-bottom: 23px;
		border-bottom: 1px solid rgba(112, 112, 112, 0.38);
		margin-bottom: 22px;
	}
	td.product-name {
		color: rgba(33, 19, 4, 1);
	}
	tfoot th, tfoot td {
		border: none !important;
		padding: 0 !important;
		font-weight: normal !important;
	}
	span.woocommerce-Price-amount.amount {
		color: #3C2300;
		font-size: 12px;
	}
	tr.cart-subtotal th, tr.cart-subtotal td {
		padding: 56px 0 22px !important;
	}
	tr.order-total th, tr.order-total td {
		border-top: 1px solid rgba(112, 112, 112, 0.38) !important;
		padding-top: 22px !important;
	}
	.order-total span.woocommerce-Price-amount.amount {
		font-size: 22px;
	}
	tr.cart-subtotal td, tr.order-total td{
		display: flex;
		justify-content: flex-end;
	}
	.woocommerce-additional-fields > h3 {
		display: none;
	}
	abbr.required {
		color: black !important;
	}
	.checkout_coupon button.button {
		background: #58B76B !important;
		color: white !important;
	}
	@media(max-width:767px){
		.custom-checkout form.checkout.woocommerce-checkout{
			display: flex;
			flex-direction: column;
			grid-gap: 0;
		}
		.checkout-title{
			text-align: center;
		}
		.woocommerce-info{
			padding: 0;
		}
		#place_order{
			font-size: 20px;
		}
		.custom-checkout .form-row label{
			margin-bottom: 5px;
		}
		.custom-checkout .form-row{
			margin-bottom: 10px !important;
		}
		#order_review{
			margin-top: 15px;
		}
		.woocommerce-billing-fields > h3{
			margin-bottom: 20px;
		}
		.woocommerce-billing-fields__field-wrapper{
			display: grid;
			grid-template-columns: 1fr 1fr;
		}
		.woocommerce form .form-row-first, .woocommerce form .form-row-last, .woocommerce-page form .form-row-first, .woocommerce-page form .form-row-last,.custom-row-last,.custom-row-first{
			width: 100%;
		}
		.select2-container--default .select2-selection--single .select2-selection__arrow{
			top: 7px;
		}
		
	}
</style>
<?php get_footer(); ?>