<?php get_header(); ?>
<?php $title = get_field("contato_titulo");
echo do_shortcode('[simple_header image="/wp-content/uploads/2021/06/simple-header-bg.png" title="'. $title . '"]'); ?>
<?php echo do_shortcode('[contato]'); ?>
<?php echo do_shortcode('[product_carousel id="18" title="Confira também nossos melhores tratamentos"]'); ?>
<section class="quem-somos">
	<?php echo do_shortcode('[agendar_visita]'); ?>
<?php
	$title = get_field("compre_seu_tratamento_titulo",23);
	$image = get_field("compre_seu_tratamento_imagem",23);
	$title_button = get_field("compre_seu_tratamento_titulo_botao",23);
	$link_button = get_field("compre_seu_tratamento_link_botao",23);
	echo do_shortcode('[banner image="'. $image . '" title="'. $title . '" title_button="'. $title_button . '" link_button="'. $link_button . '"]'); 
?>
<?php echo do_shortcode('[form_footer]'); ?>
</section>
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
			<img src="" id="imagepreview" >
		</div>
	</div>
</div>
<script>
	jQuery(function($){
		$(".pop").on("click", function() {
			$('#imagepreview').attr('src', $(this).attr('src'));
			$('#imagemodal').modal('show');
		});
	})
</script>
<style>
	.page-content{
		color: #6D6D6D;
		font-size: 14px;
	}
	.about{
		margin-bottom: 48px;
	}
	.page-title {
		font-size: 30px;
		color: #3C2300;
		margin-bottom: 45px;
	}

	.images-gallery {
		display: grid;
		grid-template-columns: 1fr 1fr 1fr;
		grid-column-gap: 46px;
		grid-row-gap: 87px;
	}
	.images-gallery img{
		cursor: pointer;
		width: 327px;
		height: 256px;
		border-radius: 5px;
		object-fit: cover;
		transition: .6s;
	}
	.images-gallery img:hover{
		opacity: 0.8;
	}
	button.close {
    position: absolute;
    right: 15px;
    top: 15px;
    color: white;
    background: black;
    opacity: 1;
    padding: 5px;
}
</style>
<?php get_footer(); ?>