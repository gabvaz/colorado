<?php

function enqueue_styles() {

	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css' );
	wp_enqueue_style( 'slick', get_template_directory_uri() . '/css/slick.css' );
	wp_enqueue_style( 'core', get_template_directory_uri() . '/style.css' );
	wp_enqueue_style( 'custom-css', get_template_directory_uri() . '/css/custom-styles.css' );

}
add_action( 'wp_enqueue_scripts', 'enqueue_styles');

function enqueue_scripts() {

	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/js/vendor/bootstrap.bundle.min.js', array( 'jquery' ) );
	wp_enqueue_script( 'slick', get_template_directory_uri() . '/js/vendor/slick.min.js', array( 'jquery' ) );
}
add_action( 'wp_enqueue_scripts', 'enqueue_scripts');

function setup_theme() 
{
	add_theme_support('woocommerce');
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );
	add_theme_support('title-tag');
	add_theme_support( 'post-thumbnails' );
	register_sidebar( array(
		'name'          => 'Filter Area',
		'id'            => 'filter_area',
		'before_widget' => '<div>',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="filter-title">',
		'after_title'   => '</h2>',
	) );
	register_nav_menus(
			array(
				'primary' => esc_html__( 'Primary menu', 'twentytwentyone' ),
				'footer'  => __( 'Secondary menu', 'twentytwentyone' ),
			)
		);
}

add_action( 'after_setup_theme', 'setup_theme' );

include( get_stylesheet_directory() . '/components/home-banner.php' );
add_shortcode( 'home_banner', 'home_banner' );
include( get_stylesheet_directory() . '/components/featured-infos.php' );
add_shortcode( 'featured_infos', 'featured_infos' );
include( get_stylesheet_directory() . '/components/all-cta.php' );
add_shortcode( 'all_cta', 'all_cta' );
include( get_stylesheet_directory() . '/components/single-small-cta.php' );
add_shortcode( 'single_small_cta', 'single_small_cta' );
include( get_stylesheet_directory() . '/components/product-carousel.php' );
add_shortcode( 'product_carousel', 'product_carousel' );
include( get_stylesheet_directory() . '/components/simple-header.php' );
add_shortcode( 'simple_header', 'simple_header' );
include( get_stylesheet_directory() . '/components/single-unidade.php' );
add_shortcode( 'single_unidade', 'single_unidade' );
include( get_stylesheet_directory() . '/components/agendar-visita.php' );
add_shortcode( 'agendar_visita', 'agendar_visita' );
include( get_stylesheet_directory() . '/components/banner.php' );
add_shortcode( 'banner', 'banner' );
include( get_stylesheet_directory() . '/components/duvidas.php' );
add_shortcode( 'duvidas', 'duvidas' );
include( get_stylesheet_directory() . '/components/form-footer.php' );
add_shortcode( 'form_footer', 'form_footer' );
include( get_stylesheet_directory() . '/components/areas-aplicacao.php' );
add_shortcode( 'areas_aplicacao', 'areas_aplicacao' );
include( get_stylesheet_directory() . '/components/sobre.php' );
add_shortcode( 'sobre', 'sobre' );
include( get_stylesheet_directory() . '/components/contato.php' );
add_shortcode( 'contato', 'contato' );




/* woocommerce hooks */
add_filter( 'woocommerce_add_to_cart_fragments', 'woocommerce_header_add_to_cart_fragment' );

function woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
	ob_start();
	?>
<a class="header-cart" href="<?php echo wc_get_cart_url(); ?>">
	<img src="http://acelerapele.sejagiga.com.br/wp-content/uploads/2021/06/shop-icon.png" />
	<div class="cart-count-">
		<?php echo WC()->cart->get_cart_contents_count(); ?>
	</div>
	<?php echo WC()->cart->get_cart_total(); ?>
</a>
	<?php
	$fragments['a.header-cart'] = ob_get_clean();
	return $fragments;
}

remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
add_action( 'woocommerce_before_shop_loop_item_title', 'custom_function_to_sort_related', 22 );
function custom_function_to_sort_related( ) {
	echo '<div class="product-image-overlay">' . woocommerce_get_product_thumbnail() . '</div>';
}
add_action( 'woocommerce_shop_loop_item_title', 'custom_session', 22 );
function custom_session( ) {
	global $post;
	$quantity = get_post_meta( $post->ID, 'quantidade', true );
	if($quantity){
		echo  '<div class="qtd">(' . $quantity . ')</div>';		
	}else{
		echo '<div class="qtd"></div>';
	}
}