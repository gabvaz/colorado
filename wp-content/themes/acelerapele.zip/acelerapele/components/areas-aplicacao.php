<?php
function areas_aplicacao() {
?>
<section id="areas-aplicacao">
	<div class="container">
		<h2 class="section-title text-center">
			<?php the_field("areas_de_aplicacao_titulo"); ?>
		</h2>
		<?php the_field("areas_de_aplicacao_descricao"); ?>
		<div class="aplicacao">
			<div class="col-md-6 img-woman active-img">
				<div class="img-center">
					<div class="circles-white">
						<img src="<?php the_field("areas_de_aplicacao_imagem");?>">
						<?php $cnt = 1; ?>
		  				<?php if(have_rows("aplicacao")): while(have_rows("aplicacao")): the_row(); ?>
						<div class="circlef" id="<?php echo 'ccollapsef' . $cnt;?>" data-toggle="collapse" data-target="<?php echo '#collapsef' . $cnt;?>"  aria-expanded="true" aria-controls="<?php echo 'collapsef' . $cnt;?>" style="<?php echo 'left:' . get_sub_field('x') . ';bottom:' . get_sub_field('y') . ';';?>"></div>
						<?php $cnt = $cnt + 1; ?>
		  				<?php endwhile; endif; ?>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-12 infos-aplicacao">
				<div id="accordion-feminino" class="active-accordion">
		  <?php $cnt = 1; ?>
		  <?php if(have_rows("aplicacao")): while(have_rows("aplicacao")): the_row(); ?>
		  <div class="card">
			<div class="card-header" id="<?php echo 'headingf' . $cnt;?>">
			  <h5 class="mb-0">
				<button class="btn btn-link" data-toggle="collapse" data-target="<?php echo '#collapsef' . $cnt;?>" aria-expanded="true" aria-controls="<?php echo 'collapsef' . $cnt;?>">
				  <?php the_sub_field("titulo"); ?>
				</button>
			  </h5>
			</div>
			<div id="<?php echo 'collapsef' . $cnt;?>" class="collapse" aria-labelledby="<?php echo 'headingf' . $cnt;?>" data-parent="#accordion-feminino">
			  <div class="card-body">
				<div class="card-body-left"><img src="<?php the_sub_field("imagem"); ?>"></div>
				<div class="card-body-right">
					<?php the_sub_field("descricao"); ?>
				</div>
			  </div>
			</div>
		  </div>
		  <?php $cnt = $cnt + 1; ?>
		  <?php endwhile; endif; ?>
		</div>
				
			</div>
		</div>
	</div>
</section>	
<style>
	#areas-aplicacao .container{
		padding-top: 75px;
		padding-bottom: 75px;
	}
	#areas-aplicacao .section-title{
		font-size: 30px;
		color: #3C2300;
		margin-bottom: 30px;
		text-transform: uppercase;
	}
	#areas-aplicacao p{
		color: #707070;
		font-size: 16px;
		margin-bottom: 0;
	}
	#areas-aplicacao .img-center{
		display: flex;
		justify-content: center;
	}
	.circles-white{
		position: relative;
	}
	.circlef,.circlem{
		position: absolute;
		border: 1px solid red;
		border-radius: 50%;
		width: 15px;
		height: 15px;
		cursor: pointer;
		transition: all .3s ease-in-out;
	}
	.active-circle{
		background: red;
	}
	.circlef:hover,.circlem:hover{
		background: red;
	}
	#areas-aplicacao .aplicacao{
		margin-top: 30px;
		display: flex;
	}
	.aplicacao .img-woman , .aplicacao .img-man{
		display: none;
	}
	.active-img,.active-accordion{
		display: block !important;
	}
	#accordion-feminino, #accordion-masculino{
		display: none;
	}
	.infos-aplicacao .fem-mas{
		display: flex;
		justify-content: space-between;
		margin-bottom: 30px;
	}
	.infos-aplicacao .fem-mas button{
		color: #9A866C;
		font-size: 20px;
		width: 230px;
		padding-top: 20px;
		padding-bottom: 20px;
		border-radius: 5px;
		border: 2px solid #9A866C;
		transition: all .3s ease-in-out;
		cursor: pointer;
	}
	.active-button{
		background: #9A866C;
		color: #FFFFFF !important;
	}
	#areas-aplicacao .card{
		width: 100%;
		border-radius: 5px;
		margin-bottom: 5px;
	}
	
	#areas-aplicacao .card .card-header{
		padding: 0;
		background: #E1B261;
		border: 0;
	}
	#areas-aplicacao .card h5 button{
		color:#FFFFFF;
		font-size: 16px;
		text-align: center;
		width: 100%;
		padding: 15px;
		text-decoration: none;
	}
	#areas-aplicacao .card h5 button:hover{
		text-decoration: none;
	}
	#areas-aplicacao .card-body{
		margin-top: 30px;
		border: 0;
		display: flex;
	}
	#areas-aplicacao .card-body .card-body-left{
		margin-right: 20px;
	}
	#areas-aplicacao .card-body .card-body-left img{
		width: 200px;
	}
	#areas-aplicacao .card-body .card-body-right p{
		font-size: 16px;
		color: #707070;
		margin-bottom: 15px;
	}
	#areas-aplicacao .card-body .card-body-right .more-details{
		background: #58B76B;
		border-radius: 5px;
		padding: 8px 60px;
	}
	#areas-aplicacao .card-body .card-body-right .more-details a{
		text-decoration: none;
		color: white;
		font-size: 16px;
	}
	@media(max-width:767px){
		.img-woman,.img-man,.circles-white{
			display: none;
			padding: 0;
		}
		.infos-aplicacao{
			padding: 0;
		}
		#feminino{
			margin-right: 15px;
		}
		#areas-aplicacao .card-body{
			flex-direction: column;
			align-items: center;
		}
		#areas-aplicacao .card-body .card-body-left{
			margin-right: 0;
		}
		.card-body-right{
			text-align: center;
			margin-top: 15px;
		}
		#areas-aplicacao .card-body{
			margin-top: 15px;
		}
	}
</style>
<script>
	jQuery(function($){
		$(document).ready(function ($) {
			$("#feminino, #masculino").click(function(){
  				$("#masculino").toggleClass("active-button");
				$("#feminino").toggleClass("active-button");
				$("#accordion-feminino").toggleClass("active-accordion");
				$("#accordion-masculino").toggleClass("active-accordion");
				$(".img-woman").toggleClass("active-img");
				$(".img-man").toggleClass("active-img");
			});
			$(".circlef").click(function(){
				if ($(this).hasClass("active-circle")){
					$(".circlef").removeClass("active-circle");
				}else{
					$(".circlef").removeClass("active-circle");
					$(this).addClass("active-circle");
				}
			});
			$(".circlem").click(function(){
				if ($(this).hasClass("active-circle")){
					$(".circlem").removeClass("active-circle");
				}else{
					$(".circlem").removeClass("active-circle");
					$(this).addClass("active-circle");
				}
			});
			$("#accordion-feminino .btn-link").click(function(){
				var alvo = $(this).data("target").replace("#","#c");
				if ($(alvo).hasClass("active-circle")){
					$(".circlef").removeClass("active-circle");
				}else{
					$(".circlef").removeClass("active-circle");
					$(alvo).addClass("active-circle");
				}
			});
			$("#accordion-masculino .btn-link").click(function(){
				var alvo = $(this).data("target").replace("#","#c");
				if ($(alvo).hasClass("active-circle")){
					$(".circlem").removeClass("active-circle");
				}else{
					$(".circlem").removeClass("active-circle");
					$(alvo).addClass("active-circle");
				}
			});
		});
	})
</script>
<?php return; }

