<?php
function form_footer() {
?>
<div class="full-row">
	<div class="container">
		<div class="row">
			<div class="offset-md-6 col-md-6 form-right col-12">
					<h2><?php the_field("formulario_titulo",23);?></h2>
					<form>
						<input type="text" id="fname" name="fname" placeholder="Digite seu Nome...">
						<input type="email" id="femail" name="femail" placeholder="Digite seu melhor Email...">
						<input type="tel" id="ftel" name="ftel" placeholder="Digite seu Telefone...">
						<input type="text" id="fprocedimento" name="fprocedimento" placeholder="Procedimento">
						<input type="text" id="funidade" name="funidade" placeholder="Unidade">
						<input type="submit" value="ENVIAR">
					</form>
			</div>
		</div>
	</div>

</div>

<style>
	@media(max-width:767px){
		.full-row{
			background-image: none !important;
			background-size: 0%;
		}
		.offset-md-6.col-md-6.form-right {
    		padding: 60px 0 75px 0 !important;
		}
		.form-right h2{
			font-size: 25px;
			margin-bottom: 30px;
			text-align: center;
		}
		.row{
			margin-left: 0;
		}
	}
	.full-row{
		background-image: url(<?php the_field("formulario_imagem",23);?>);
		background-size: 50%;
		background-position: left;		
    	background-repeat: no-repeat;
		background-color: #E2D8CA;
	}
	
	.form-left{
		padding-right: 0;
	}
	.form-right{
		padding-left: 0;
		padding-right: 0;
	}
	.offset-md-6.col-md-6.form-right {
    padding: 60px 0 60px 60px;
}
	.row{
		margin-right: 0;
	}
	.form-left img{
		width: 100%;
	}
	.form-right form{
		display: flex;
		flex-direction: column;
	}
	.form-right form input{
		width: 100%;
		padding: 10px 20px;
		border: 0;
		border-radius: 5px;
		color: #A7A7A7;
		font-size: 14px;
		margin-bottom: 10px;
	}
	.form-right form input:focus{
		outline: none;
	}
	.form-right form input:last-child{
		margin-bottom: 0;
		margin-top: 10px;
	}
	.form-right form input[type="submit"]{
		padding-top: 15px;
		padding-bottom: 15px;
		color: #FFFFFF;
		text-transform: uppercase;
		font-size: 18px;
		text-align: center;
		cursor: pointer;
		background: #E1B261;
	}
	.form-right{
		display: flex;
		flex-direction: column;
		justify-content: center;
		background: #E2D8CA;
	}
	.form-right h2{
		font-size: 30px;
		color: #001329;
		margin-bottom: 45px;
	}
</style>
<?php return; }

