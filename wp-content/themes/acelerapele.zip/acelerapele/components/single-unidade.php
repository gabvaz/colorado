<?php
function single_unidade( $atts ) {
	$params = shortcode_atts( array(
		'title' => '',
		'infos' => '',
		'zap' => '',
		'tel' => '',
		'mapa' => ''
	), $atts );
?>
<div class="single-unidade">
	<div class="mapa">
		<iframe src="<?php echo  $params['mapa']; ?>" width="100%" height="150" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
	</div>
	<div class="infos">
		<div class="infos-left">
			<h2><?php echo  $params['title']; ?></h2>
			<?php echo $params['infos']; ?>
		</div>
		<div class="infos-right">
			<a href="<?php echo  $params['zap']; ?>">
				<div class="zap">WHATSAPP</div>
			</a>
			<a href="<?php echo  $params['tel']; ?>">
				<div class="tel">TELEFONAR</div>
			</a>
		</div>
	</div>
</div>
<style>
	
	.single-unidade{
		width: 375px;
		background: #F5EEE1;
		border-radius: 0 0 5px 5px;
	}
	.infos{
		display: flex;
		padding: 15px 12px 15px 12px;
	}
	.infos-right{
		margin-top: 15px;
	}
	.infos-right div{
		width: 120px;
		height: 45px;
		margin-bottom: 15px;
		border-radius: 5px;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.zap{
		background: #25D366;
	}
	.tel{
		background: #9A866C;
	}
	.infos-right a{
		color: #FFFFFF;
		font-size: 12px;
		text-transform: uppercase;
		text-align: center;
		text-decoration: none;
	}
	.infos-left h2{
		color: #3C2300;
		font-size: 16px;
		margin-top: 0;
		margin-bottom: 10px;
	}
	.infos-left h6{
		font-size: 12px;
		color: #9A866C;
		margin-top: 0;
		margin-bottom: 5px;
	}
	.infos-left p{
		font-size: 12px;
		color: #3C2300;
		margin-top: 0;
		margin-bottom: 10px;
	}
	@media(max-width:767px){
		.infos-left{
			padding-right: 30px;	
		}			
		.single-unidade{
			width: 100%;
		}
		
	}
	
</style>
<?php return; }

