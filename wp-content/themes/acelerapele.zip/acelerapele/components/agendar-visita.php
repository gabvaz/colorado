<?php
function agendar_visita(  ) {

?>
<div class="container-fluid agendar-visita">
	<h4 class="section-title text-center">
		<?php the_field("agende_uma_visita_titulo",23); ?>
	</h4>
	<a class="agendar-visita-link" href="<?php the_field("agende_uma_visita_link_botao",23); ?>">
		<button><?php the_field("agende_uma_visita_titulo_botao",23); ?></button>
	</a>
</div>
<style>
	.agendar-visita{
		padding-top:50px; 
		padding-bottom: 80px;
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	.section-title{
		color: #3C2300;
		font-size: 30px;
		margin-top: 0;
		margin-bottom: 30px !important;
	}
	.agendar-visita-link{
		text-align: center;
		cursor: pointer;
	}
	.agendar-visita-link button{
		background: #E1B261;
		padding: 20px 60px;
		color: #FFFFFF;
		font-size: 20px;
		border-radius: 5px;
		border: 0;
		outline: 0;
		cursor: pointer;
	}
	.agendar-visita{
		background: #E9E2D4;
		position: relative;
		z-index: 1;
	}
	.overlay {
		position: absolute;
		top: 0;
		left: 0;
		height: 100%;
		width: 100%;
		background: #322600;
		opacity: 0.55;
		z-index: -1;
	}
	@media(max-width:767px){
		.section-title{
			font-size: 25px;
			padding-top: 45px;
			padding-bottom: 45px;
		}
		.banner-title{
			width: 75%;
		}
		#agendar-visita-banner p {
    margin-bottom: 0;
    font-size: 25px;
    padding: 0 30px;
}
	}
</style>
<?php return; }

