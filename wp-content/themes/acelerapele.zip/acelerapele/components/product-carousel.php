<?php
function product_carousel( $atts ) {
	$params = shortcode_atts( array(
		'id' => '0',
		'title' => 'Tratamentos...',
		'link' => '/'
	), $atts );
	$query = new WP_Query( array(
		'post_type'             => 'product',
		'post_status'           => 'publish',
		'ignore_sticky_posts'   => 1,
		'posts_per_page'        => -1,
		'tax_query'             => array(
			array(
				'taxonomy'      => 'product_cat',
				'terms'         => $params['id'],
				'operator'      => 'IN'
			),
		)
	));
?>
<section class="qs">
	<div class="container">
		<div class="quem-somos-products">
			<div class="carousel-title">
				<h4 class="section-title text-center">
					<?php echo  $params['title']; ?>
				</h4>
			</div>
			<?php
	if($query->have_posts()) :
	echo '<div class="products d-flex align-items-center">';
	while($query->have_posts()) : 
	$query->the_post(); 
	$product = wc_get_product( get_the_id() );
			?>
			<div class="product">
				<a href="<?php the_permalink(); ?>">
					<div class="product-image-overlay">
						<img src="<?php the_post_thumbnail_url('shop_catalog'); ?>" class="woocommerce-placeholder wp-post-image" alt="Padrão" loading="lazy">
					</div>
					<h2 class="woocommerce-loop-product__title" style="margin-top: 15px;"><?php the_title(); ?></h2>
					<?php
	global $post;
	$quantity = get_post_meta( $post->ID, 'quantidade', true );
	if($quantity){
		echo  '<div class="qtd">(' . $quantity . ')</div>';		
	}else{
		echo '<div class="qtd"></div>';
	}
	?>
					<span class="fswp_installment_prefix">Em até 10x de </span>
					<span class="price">
						<span class="amount">
							<?php echo "R$" . number_format($product->get_price()/10, 2, ',', ''); ?>
						</span>
					</span>
				</a>
				<a href="?add-to-cart=<?php the_id(); ?>" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="<?php the_id(); ?>" data-product_sku="" aria-label="Adicionar “<?php echo get_the_title(); ?>” no seu carrinho" rel="nofollow">
					Adicionar ao carrinho
				</a>
				<a class="custom-buy" href="<?php the_permalink(); ?>">
					Comprar
				</a>
			</div>
			<?php endwhile; echo '</div>'; endif; wp_reset_postdata(); ?>
			<div class="carousel-footer text-center">
				<a class="more-products" href="<?php echo $params['link'];?>">Ver mais tratamentos</a>
			</div>
		</div>
	</div>
</section>

<script>
	jQuery(function($){
		$(document).ready(function ($) {
			$('.products').slick({
				dots: false,
				infinite: true,
				slidesToShow: 4,
				slidesToScroll: 1,
				autoplay: false,
				draggable: true,
				arrows: true,
				prevArrow: '<img class="arrow-left arrow" src="/wp-content/uploads/2021/06/arrow.png">',
				nextArrow: '<img class="arrow-right arrow" src="/wp-content/uploads/2021/06/arrow.png">',
				responsive: [
					{
						breakpoint: 1024,
						settings:"unslick"
					}
				]
			});
		})
	})
</script>
<style>
	.product-carousel-2 .product{
		background: #E2D8CA !important;
	}
	.quem-somos-products {
		padding: 90px 0 90px;
	}
	.qs{
		background: #EAE8E6;
	}
	.product.slick-slide{
		margin: 0 15px;
	}
	.product.slick-slide img{
		max-width: 100%;
		border-radius: 5px 5px 0 0;
		border: none !important;
		margin-bottom: 30px;
	}
	.product .added::after {
		font-family: WooCommerce;
		content: "\e017";
		margin-left: .53em;
		vertical-align: bottom;
	}
	.product .loading{
		opacity: .25;
		padding-right: 2.618em;
		position: relative;
	}
	.product .loading::after {
		font-family: WooCommerce;
		content: "\e01c";
		vertical-align: top;
		font-weight: 400;
		position: absolute;
		top: .618em;
		right: 1em;
		-webkit-animation: spin 2s linear infinite;
		animation: spin 2s linear infinite;
	}
	.more-products {
		background: #3C2300;
		color: white;
		border-radius: 5px;
		padding: 15px 20px;
		margin-top: 57px;
		display: inline-block;
		text-transform: uppercase;
		font-size: 20px;
	}
	h4.section-title.text-center {
		color: #3C2300;
		margin-bottom: 60px !important;
		text-transform: uppercase;
		font-size: 30px;
	}
	.arrow:hover{
		cursor: pointer;
	}
	.arrow-right{
		transform: rotate(180deg);
	}
	@media(max-width:767px){
		.section-title{
			padding: 0 !important;
		}
		.quem-somos-products{
			padding: 90px 0 80px 0;
		}
		.products {
			display: grid !important;
			grid-template-columns: 1fr 1fr;
			grid-gap: 14px;
			align-items: flex-start !important;
		}
		.products img{
			max-width: 100%;
		}
	}
</style>
<?php return; }

