<?php
function home_banner() {
?>
<div class="banners">
	<?php
	if(have_rows("banners")): 
	while(have_rows("banners")): the_row();
	?>
	<a href="#" class="banner-content-principal">
		<img src="<?php the_sub_field('imagem'); ?>" style="width: 100%;">
	</a>
	<?php
	endwhile; 
	endif;
	?>
</div>
<script>
	jQuery(function($){
		$(document).ready(function ($) {
			$('.banners').slick({
				dots: true,
				infinite: true,
				slidesToShow: 1,
				slidesToScroll: 1,
				autoplay: false,
				draggable: true,
				arrows: false,
			});
		})
	})
</script>
<style>
	.banners ul.slick-dots {
		display: flex;
		align-items: center;
		justify-content: center;
		position: absolute;
		bottom: 0;
		width: 100%;
		list-style: none;
		padding: 0;
	}
	.banner-content-principal:hover{
		opacity: 1;
	}
	.banners .slick-dots li button {
		border: 1px solid #C1C1C1;
		border-radius: 50%;
		font-size: 0;
		padding: 6px;
		color: transparent;
		background: transparent;
		cursor: pointer;
	}
	.banners .slick-dots .slick-active button{
		background: #C1C1C1;
	}
	.banners .slick-dots li {
		padding: 0 3px;
	}
	.banner__{
		display: flex;
		justify-content: flex-end;
	}
	.banner-content{
    padding: 120px 40px 20px 0px;
	}
	@media(min-width: 1024px){
		.banners{
			margin-top: 62px;
		}
	}
</style>
<?php return; }

