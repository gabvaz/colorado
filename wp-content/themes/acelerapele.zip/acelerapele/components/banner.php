<?php
function banner( $atts ) {
	$params = shortcode_atts( array(
		'image' => '',
		'title' => '',
		'title_button' => '',
		'link_button' => ''
	), $atts );
?>
<div class="container-fluid header-banner">
	<div class="overlay"></div>
	<h4 class="banner-title text-center">
		<?php echo  $params['title']; ?>
	</h4>
	<a class="banner-link" href="<?php echo $params['link_button']; ?>">
		<button><?php echo $params['title_button']; ?></button>
	</a>
</div>
<style>
	.banner-title{
		color: white;
		font-size: 30px;
		margin-bottom: 30px;
		text-transform: uppercase;
	}
	.banner-link{
		text-align: center;
	}
	.banner-link button{
		background: #58B76B;
		padding: 15px 75px;
		color: #FFFFFF;
		font-size: 16px;
		border-radius: 5px;
		border: 0;
		outline: 0;
		cursor: pointer;
		text-transform: uppercase;
	}
	.header-banner{
		background-image: url('<?php echo $params['image']; ?>');
		padding: 70px 0px 70px;
		position: relative;
		background-size: cover;
		z-index: 1;
		display: flex;
		flex-direction: column;
		align-items: center;
		min-height: 281px;
	}
	.overlay {
		position: absolute;
		top: 0;
		left: 0;
		height: 100%;
		width: 100%;
		background: #211304;
		opacity: 0.48;
		z-index: -1;
	}
	h4.banner-title.text-center {
    max-width: 776px;
}
</style>
<?php return; }

