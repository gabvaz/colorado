<?php function all_cta(){ ?>
<div class="container">
	<div class="destaques-wrapper">
		<?php 
	if(have_rows("destaques")):
	while(have_rows("destaques")): the_row();
	$text_1 = get_sub_field("texto_1");
	$text_2 = get_sub_field("texto_2");
	$link = get_sub_field("link");
	$background = get_sub_field("background");
	echo do_shortcode('[single_small_cta text_1="'.$text_1.'" text_2="'.$text_2.'" link="'.$link.'" background="'.$background.'"]'); 
	endwhile; endif;
		?>
	</div>
</div>
<style>
	.destaques-wrapper {
		display: grid;
		grid-template-columns: repeat(3,1fr);
		grid-column-gap: 36px;
		padding: 30px 0;
	}
	.single-small-cta{
		padding: 36px 15px 37px 15px;
		border-radius: 5px;
		position: relative;
		z-index: 2;
	}
	.cta-text {
		font-size: 18px;
		text-transform: uppercase;
	}
	.cta-text-1{
		color: #FFD092;
	}
	.cta-text-2{
		color: white;
	}
	.cta-link {
		background: white;
		border-radius: 50%;
		padding: 8px;
	}
	.cta-overlay {
		position: absolute;
		width: 100%;
		height: 100%;
		background: #977237;
		opacity: 0.63;
		top: 0;
		left: 0;
		border-radius: 5px;
		z-index: -1;
	}
	@media(max-width:767px){
		.destaques-wrapper{
			grid-template-columns: 1fr;
			grid-column-gap: 0px;
			grid-row-gap: 30px;
		}
	}
</style>
<?php return; } ?>