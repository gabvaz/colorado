<?php function contato() { ?>
<section id="contato">
	<div class="container">
		<div class="form-image">
			<div class="image col-md-6 col-12">
				<img src="/wp-content/uploads/2021/08/Grupo-de-mascara-75.jpg">
			</div>
			<div class="form-contato col-md-6 col-12">
				<h2><?php the_field("contato_titulo_formulario",192);?></h2>
				<form>
					<input type="text" id="fname" name="fname" placeholder="Digite seu Nome...">
					<input type="email" id="femail" name="femail" placeholder="Digite seu melhor Email...">
					<input type="tel" id="ftel" name="ftel" placeholder="Digite seu Telefone...">
					<input type="text" id="fprocedimento" name="fprocedimento" placeholder="Procedimento">
					<input type="text" id="funidade" name="funidade" placeholder="Unidade">
					<input type="submit" value="ENVIAR">
				</form>
			</div>
		</div>
		<div class="infos">
			<div class="info">
				<img src="<?php the_field("horario_de_funcionamento_icone",192);?>">
				<h4><?php the_field("horario_de_funcionamento_titulo",192);?></h4>
				<?php the_field("horario_de_funcionamento_descricao",192);?>
			</div>
			<div class="info">
				<img src="<?php the_field("telefone_icone",192);?>">
				<h4><?php the_field("telefone_titulo",192);?></h4>
				<?php the_field("telefone_descricao",192);?>
			</div>
			<div class="info">
				<img src="<?php the_field("localizacao_icone",192);?>">
				<h4><?php the_field("localizacao_titulo",192);?></h4>
				<?php the_field("localizacao_descricao",192);?>
			</div>
		</div>
	</div>
</section>
<style>
	@media(max-width:767px){
		#contato .container .form-image{
			flex-direction: column;
		}
		#contato .container .form-contato h2{
			margin-bottom: 30px !important;
			font-size: 25px; 
			margin-top: 45px;
		}
		#contato .image{
			padding: 0 !important;
		}
		#contato .image img{
			width: 100% !important;
			height: auto !important;
		}
		#contato .container .form-contato{
			padding: 0 !important;
		}
		#contato .container .infos{
			flex-direction: column;
		}
		#contato .container .infos{
			margin-top: 70px;
		}
		#contato .info{
			margin-bottom: 70px;
		}
		#contato .container .info p{
			text-align: center;
		}
		#contato .container .infos{
			margin-bottom: 0 !important;
		}
	}
	#contato{
		padding-top: 30px;
		padding-bottom: 0;
	}
	#contato .container .form-image{
		display: flex;
		align-items: center;
	}
	#contato .container .form-image .image{
		padding-left: 0;
	}
	#contato .container .form-image img{
		width: 400px;
		height: 300px;
	}
	#contato .container .form-contato{
		display: flex;
		flex-direction: column;
		padding: 0 45px;
	}
	#contato .container .form-contato h2{
		color: #001329;
		font-size: 18px;
		text-align: center;
		margin-bottom: 15px;
	}
	#contato .container .form-contato input{
		border-radius: 5px;
		border: 1px solid #CECECE;
		width: 100%;
		padding: 8px 15px;
		font-size: 12px;
		color: #A7A7A7;
		margin-bottom: 10px;
	}
	#contato .container .form-contato input:focus{
		outline: none;
	}
	#contato .container .form-contato input[type="SUBMIT"]{
		background: #E1B261;
		border: 0px;
		color: #FFFFFF;
		font-size: 12px;
		padding: 12px 0;
		cursor: pointer;
	}
	#contato .container .infos{
		display: flex;
		justify-content: space-around;
		margin-top: 50px;
		margin-bottom: 90px;
	}
	#contato .container .info{
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	#contato .container .info h4{
		color: #3C2300;
		font-weight: 700;
		font-size: 18px;
		text-align: center;
		margin-bottom: 10px;
	} 
	#contato .container .info img{
		width: 60px;
		height: 60px;
		border-radius: 50%;
		background: #3C2300;
		margin-bottom: 15px;
	}
	#contato .container .info p{
		color: #8E6730;
		font-size: 15px;
		margin-bottom: 8px;
	}
	#contato .container .info p:last-child{
		margin-bottom: 0;
	}
	
	
</style>
<?php return; } ?>