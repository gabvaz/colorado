<?php function sobre() { ?>
<div class="sobre-container">
	<div class="container">
		<h3 class="sobre-title"><?php the_field("sobre_titulo",23); ?></h3>
		<div class="sobre-content">
			<div class="content">
				<div class="text">
					<?php the_field("sobre_descricao",23); ?>
				</div>			
				<a class="sobre-link"href="/quem-somos"><?php the_field("sobre_texto_botao",23); ?></a>
			</div>
			<div class="sobre-image">
				<img src="<?php the_field("sobre_imagem",23); ?>" style="max-width: 100%;">
			</div>
		</div>
	</div>
</div>

<style>
	.sobre-title{
		color: #3C2300;
		font-size: 30px;
		text-align: center;
		margin-bottom: 48px;
	}
	.sobre-container{
		background: url('/wp-content/uploads/2021/06/background-home-1.png');
		padding-bottom: 160px;
	}
	.sobre-content {
		display: grid;
		grid-template-columns: 1fr 1fr;
		grid-column-gap: 67px;
		padding: 0 120px;
	}
	.sobre-link{
		background: #E1B261;
		border-radius: 5px;
		color: #FFFFFF;
		padding: 10px 30px;
		display: inline-block;
		margin-top: 60px;
	}
	.sobre{
		padding-top: 90px;
	}
	@media(max-width:767px){
		.sobre{
			padding-top: 0;
		}
		.sobre-content{
			display: flex;
			flex-direction: column;
			align-items: center;
			grid-column-gap: 0;
			padding: 0;
		}
		.text{
			margin-top: 30px;
		}
		.sobre-link{
			margin-top: 45px;
		}
		.sobre-container{
			padding-bottom: 60px;
		}
		.content{
			order: 2;
			display: flex;
			flex-direction: column;
			align-items: center;
		}
	}
</style>
<?php return; } ?>