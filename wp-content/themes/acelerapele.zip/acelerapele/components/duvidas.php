<?php
function duvidas() {
?>
<section id="faq">
	<div class="overlay-faq"></div>
	<div class="container">
		<h2><?php the_field("duvidas_titulo",23);?></h2>
		<div id="accordion">
		  <?php $cnt = 1; ?>
		  <?php if(have_rows("duvidas",23)): while(have_rows("duvidas",23)): the_row(); ?>
		  <div class="card">
			<div class="card-header" id="<?php echo 'heading' . $cnt;?>">
			  <h5 class="mb-0">
				<button class="btn btn-link" data-toggle="collapse" data-target="<?php echo '#collapse' . $cnt;?>" aria-expanded="true" aria-controls="<?php echo 'collapse' . $cnt;?>">
				  <?php the_sub_field("pergunta",23); ?>
				</button>
				<img src="/wp-content/uploads/2021/08/add.png" class="plus-duvidas" data-toggle="collapse" data-target="<?php echo '#collapse' . $cnt;?>" aria-expanded="true" aria-controls="<?php echo 'collapse' . $cnt;?>">
				<img src="/wp-content/uploads/2021/08/minus-sign.png" class="minus-duvidas" data-toggle="collapse" data-target="<?php echo '#collapse' . $cnt;?>" aria-expanded="true" aria-controls="<?php echo 'collapse' . $cnt;?>">
			  </h5>
			</div>
			<div id="<?php echo 'collapse' . $cnt;?>" class="collapse" aria-labelledby="<?php echo 'heading' . $cnt;?>" data-parent="#accordion">
			  <div class="card-body"><?php the_sub_field("resposta",23); ?></div>
			</div>
		  </div>
		  <?php $cnt = $cnt + 1; ?>
		  <?php endwhile; endif; ?>
		</div>
	</div>
</section>
<style>
	#faq{
		padding-top: 90px;
		padding-bottom: 90px;
		position: relative;
	}
	#faq .mb-0{
		position: relative;
	}
	.plus-duvidas, .minus-duvidas{
		position: absolute;
		top: 50%;
		transform: translatey(-50%);
		right: 15px;
		cursor: pointer;
	}
	.plus-duvidas{
		display: block;
	}
	.minus-duvidas{
		display: none;
	}
	.card-header-active .plus-duvidas{
		display: none;
	}
	.card-header-active .minus-duvidas{
		display: block;
	}
	.overlay-faq{
		position: absolute;
		top: 0;
		left: 0;
		height: 100%;
		width: 100%;
		background: #C89C84;
		opacity: 0.2;
		z-index: -1;
	}
	#faq .card{
		border: 0;
		margin-bottom: 15px;
		background: transparent;
	}
	#faq .card:last-child{
		margin-bottom: 0;
	}
	#faq .btn{
		width: 100%;
		padding: 15px 10px 15px 20px;
		text-align: left;
	}
	#faq h2{
		text-align: center;
		color: #3C2300;
		text-transform: uppercase;
		font-size: 30px;
		margin-bottom: 45px;
	}
	#faq .card-body{
		padding: 50px 20px;
		background: #ffffff;
	}
	#faq .card-header{
		border-radius: 8px !important; 
		padding: 0;
		border: 1px solid #3C2300;
		background: transparent;
		transition: all .3s ease-in-out;
	}
	#faq .card-header-active{
		background: #9A866C;
		border-radius: 8px 8px 0 0 !important;
		border: 0;
	}
	#faq .card-header-active button{
		color: #ffffff !important;
	}
	#faq .card-header button{
		text-transform: uppercase;
		color: #3C2300;
		font-weight: 700;
		font-size: 18px;
		text-decoration: none;
	}
	#faq .card-header button:hover{
		text-decoration: none;
		color: #3C2300;
	}
	#faq .card-body p{
		color: #00253B;
		font-size: 18px;
	}
	@media(max-width:767px){
		#faq h2{
			margin-bottom: 45px;
			font-size: 25px;
		}
		#faq{
			padding-top: 45px;
		}
		#faq .card-header button{
			font-size: 14px;	
		}
	}
</style>
<script>
	jQuery(function($){
		$(document).ready(function ($) {
			$(".card-header").click(function(){
				if ($(this).hasClass("card-header-active")){
					$(".card-header").removeClass("card-header-active");
					$(this).addClass("card-header-active");
				}else{
					$(".card-header").removeClass("card-header-active");
				}
  				$(this).toggleClass("card-header-active");
			});
		});
	})
</script>
<?php return; }

