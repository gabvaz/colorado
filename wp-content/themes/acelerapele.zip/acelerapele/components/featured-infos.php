<?php function featured_infos(){ ?>
<div class="featured-area">
	<div class="container">
	<div class="icons-wrapper">
		<div class="single-info">
			<div class="info-icon-area">
				<img src="/wp-content/uploads/2021/09/pele-icones-01.png">
			</div>
			<div class="info-text">
				ESCOLHA SEU TRATAMENTO
			</div>
		</div>
		<div class="single-info">
			<div class="info-icon-area">
				<img src="/wp-content/uploads/2021/09/pele-icones-02.png">
			</div>
			<div class="info-text">
				PAGUE ONLINE
			</div>
		</div>
		<div class="single-info">
			<div class="info-icon-area">
				<img src="/wp-content/uploads/2021/09/pele-icones-03.png">
			</div>
			<div class="info-text">
				PARCELE EM ATÉ 10X NO CARTÃO
			</div>
		</div>
		<div class="single-info">
			<div class="info-icon-area">
				<img src="/wp-content/uploads/2021/09/pele-icones-04.png">
			</div>
			<div class="info-text">
				AGENDE DATA E HORÁRIO
			</div>
		</div>
	</div>
</div>
</div>

<style>
	.featured-area{
		background: #EAE8E6;
		padding: 16px 0;
	}
	.icons-wrapper{
		display: grid;
		grid-template-columns: repeat(4,1fr);
		grid-column-gap: 50px;
		width: 100%;
		justify-content: center;
	}
	.single-info {
    display: flex;
    align-items: center;
}
	.info-icon-area{
		display: flex;
		align-items: center;
		justify-content: center;
		border: 3px solid #3C2300;
		border-radius: 50%;
		padding: 5px;
		margin-right: 20px;
	}
	.info-text{
		color: #211304;
		text-transform: uppercase;
		font-size: 18px;
	}
	@media(max-width:767px){
		.featured-area{
			display: none;
		}
	}
	.single-info img {
    	    width: 57px;
	}
</style>
<?php return; } ?>