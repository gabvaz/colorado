<?php function single_small_cta( $atts ) { 
$params = shortcode_atts( array(
		'text_1' => '',
		'text_2' => '',
		'background' => '',
		'link' => '',
	), $atts );
?>
<div class="single-small-cta "style="background: url('<?php echo $params['background']; ?>');background-repeat:no-repeat;background-size:cover;">
	<a href="<?php echo $params['link']; ?>">
		<div class="cta-overlay"></div>
		<p class="cta-text cta-text-1">
			<?php echo $params['text_1']; ?>
		</p>
		<p class="cta-text cta-text-2">
			<?php echo $params['text_2']; ?>
		</p>
		<div style="display:flex;justify-content:flex-end;">
			
		
		<a class="cta-link" href="<?php echo $params['link']; ?>">
		<img src="/wp-content/uploads/2021/06/arrow-transparent.png">
		</a>
		</div>
	</a>
</div>
<style>
	.cta-text{
		line-height: 1.1;
	}
	.cta-link{
		padding: 14px !important;
		position: relative;
	}
	.cta-link img{
		position: absolute;
		left: 50%;
		transform: translate(-50%,-50%);
	}
	.single-small-cta span{
		font-size: 30px;
		margin: 0;
		font-family: Futura-Book !important;
		color: #ffffff;
		font-weight: bold;
	}
</style>
<?php return; } ?>