<?php
function simple_header( $atts ) {
	$params = shortcode_atts( array(
		'image' => '#',
		'title' => '...'
	), $atts );
?>
<div class="container-fluid simple-header">
	<div class="overlay"></div>
	<h4 class="section-page-title text-center">
		<?php echo  $params['title']; ?>
	</h4>
</div>
<style>
	.section-page-title{
		color: white;
		font-size: 30px;
	}
	.simple-header {
    background-image: url('<?php echo $params['image']; ?>');
    padding: 140px 0px 55px;
    position: relative;
	background-size: cover;
    z-index: 1;
}
	.overlay {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background: #BB8834 !important;
    opacity: 0.55 !important;
    z-index: -1;
}
	@media(max-width: 1023px){
		.simple-header {
		 padding: 170px 0px 55px;
		}
	}
</style>
<?php return; }

