<?php get_header(); ?>
<?php $title = 'QUEM SOMOS';
echo do_shortcode('[simple_header image="/wp-content/uploads/2021/06/simple-header-bg.png" title="'. $title . '"]'); ?>

<section class="quem-somos">
	<div class="container">
		<div class="about">
			<h4 class="page-title">
				CONHEÇA A PELE
			</h4>
			<p class="page-content">
				<?php the_field('conheca_a_pele'); ?>
			</p>
		</div>
		<div class="gallery">
			<h4 class="page-title">
				ESPAÇO ACONCHEGANTE
			</h4>
			<div class="images-gallery">
				<?php 
				$images = get_field('espaco');
				if( $images ): ?>
				<?php foreach( $images as $image_url ): ?>
				<?php echo '<img src="' . $image_url . '" class="pop">'; ?>
				<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
		
	</div>
</section>

<?php echo do_shortcode('[product_carousel id="45" title="Confira nossos melhores tratamentos"]'); ?>
	
<section>
	<?php echo do_shortcode('[agendar_visita]'); ?>
<?php
	$title = get_field("compre_seu_tratamento_titulo",23);
	$image = get_field("compre_seu_tratamento_imagem",23);
	$title_button = get_field("compre_seu_tratamento_titulo_botao",23);
	$link_button = get_field("compre_seu_tratamento_link_botao",23);
	echo do_shortcode('[banner image="'. $image . '" title="'. $title . '" title_button="'. $title_button . '" link_button="'. $link_button . '"]'); 
?>
<?php echo do_shortcode('[form_footer]'); ?>
</section>
<div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
			<img src="" id="imagepreview" >
		</div>
	</div>
</div>
<script>
	jQuery(function($){
		$(".pop").on("click", function() {
			$('#imagepreview').attr('src', $(this).attr('src'));
			$('#imagemodal').modal('show');
		});
	})
</script>
<style>
	@media(max-width:767px){
		.page-title{
			font-size: 25px;
			margin-bottom: 45px;
			text-align: center;
		}
		.about{
			margin-bottom: 60px;
		}
		.images-gallery{
			grid-template-columns: 1fr !important;
			grid-column-gap: 0;
			grid-row-gap: 45px;
		}
		.images-gallery img{
			width: 100% !important;
			height: 268px !important;
		}
		
		.page-content{
			text-align: center;
		}
	}
	
	.gallery{
		margin-bottom: 90px;
	}
	
	.page-content{
		color: #6D6D6D;
		font-size: 14px;
	}
	.about{
		margin-bottom: 48px;
	}
	.page-title {
		font-size: 30px;
		color: #3C2300;
		margin-bottom: 45px;
	}
	.quem-somos{
		padding-top: 40px;
	}
	.images-gallery {
		display: grid;
		grid-template-columns: 1fr 1fr 1fr;
		grid-column-gap: 46px;
		grid-row-gap: 87px;
	}
	.images-gallery img{
		cursor: pointer;
		width: 327px;
		height: 256px;
		border-radius: 5px;
		object-fit: cover;
		transition: .6s;
	}
	.images-gallery img:hover{
		opacity: 0.8;
	}
	button.close {
    position: absolute;
    right: 15px;
    top: 15px;
    color: white;
    background: black;
    opacity: 1;
    padding: 5px;
}
</style>
<?php get_footer(); ?>