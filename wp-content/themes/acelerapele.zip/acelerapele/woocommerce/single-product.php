<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$title = 'TRATAMENTO ' . strtoupper(get_the_title());
echo do_shortcode('[simple_header image="/wp-content/uploads/2021/06/simple-header-bg.png" title="'. $title . '"]');
get_header( 'shop' ); ?>
<div class="container custom-shop">
	<?php
	/**
		 * woocommerce_before_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */
	do_action( 'woocommerce_before_main_content' );
	?>

	<?php while ( have_posts() ) : ?>
	<?php the_post(); ?>

	<?php wc_get_template_part( 'content', 'single-product' ); ?>

	<?php endwhile; // end of the loop. ?>

	<?php
	/**
		 * woocommerce_after_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
	do_action( 'woocommerce_after_main_content' );
	?>
	</div>

<?php
	$title = 'NÃO ENCONTROU O QUE QUERIA? CLIQUE PARA BUSCAR POR OUTROS TRATAMENTOS';
	$image = '/wp-content/uploads/2021/06/close-up-sensual-beautiful-woman-face.png';
	$title_button = 'VER MAIS';
	$link_button = '/tratamentos';
	echo do_shortcode('[banner image="'. $image . '" title="'. $title . '" title_button="'. $title_button . '" link_button="'. $link_button . '"]'); 
echo do_shortcode('[form_footer]'); ?>
<script>
	jQuery(function($){
		var timeout;
		$('.woocommerce').on('click', 'input.more-less', function(){
			var qtdBtn = $(this).parent().find('.qty');
			var signal = parseInt($(this).attr('data-signal'));
			qtdBtn.val(String(parseInt(Math.max(0,parseInt(qtdBtn.val()) + signal))));
		});
		$(document).ready(function ($) {
			$('ul.products.columns-4').slick({
				dots: false,
				infinite: true,
				slidesToShow: 4,
				slidesToScroll: 1,
				autoplay: false,
				draggable: true,
				arrows: true,
				prevArrow: '<img class="arrow-left arrow" src="/wp-content/uploads/2021/06/arrow.png">',
				nextArrow: '<img class="arrow-right arrow" src="/wp-content/uploads/2021/06/arrow.png">',
				responsive: [
					{
						breakpoint: 1024,
						settings:"unslick"
					}
				]
			});
		})
	})
</script>
<style>
	main#main > .product {
		background: transparent;
	}
	.custom-shop .group-inputs {
		width: 120px;
		justify-content: space-around;
		padding: 5px 0;
	}
	.custom-shop .quantity .qty {
		width: 1.7rem;
		border: none;
	}
	.custom-shop form.cart {
		display: flex;
	}
	.custom-shop .wp-video {
    max-width: 769px;
    margin: 0 auto 50px;
}
	.custom-shop button.single_add_to_cart_button.button.alt {
		background: #E1B261;
		margin-left: 27px;
		border-radius: 5px;
		font-weight: normal;
		font-size: 12px;
		width: 239px;
		text-transform: uppercase;
	}
	.custom-shop ul.tabs.wc-tabs {
    display: none;
}
	.custom-shop div.product div.images{
		margin-bottom: 120px;
	}
	.custom-shop div#tab-description > h2, section.related.products > h2 {
    font-size: 24px;
    margin-bottom: 42px;
    text-align: center;
    color: #3C2300;
}
	.custom-shop button.single_add_to_cart_button.button.alt img{
		margin-right: 10px;
		margin-top: -8px;
	}
	.custom-shop .product_meta {
		margin-top: 80px;
		display: flex;
		flex-direction: column;
	}
	.product_meta span, .product_meta a {
		color: #3C2300 !important;
		font-size: 16px;
	}
	.custom-shop h1.product_title.entry-title {
		color: #3C2300;
		font-size: 24px;
	}
	.summary.entry-summary span.woocommerce-Price-amount.amount{
		padding-left: 0 !important;
	}
	.custom-shop .product{
		height: auto;
	}
	.custom-shop .woocommerce-product-details__short-description p {
		color: #6D6D6D;
		font-size: 14px;
	}
	.custom-shop{
		margin-top: 42px;
	}
	.custom-shop .flex-viewport {
		margin-bottom: 43px;
	}
	.custom-shop ol.flex-control-nav.flex-control-thumbs {
		display: grid;
		grid-template-columns: repeat(3,1fr);
		grid-gap: 47px;
	}
	.custom-shop ol.flex-control-nav.flex-control-thumbs li{
		width: 100% !important;
	}
	.custom-shop ol.flex-control-nav.flex-control-thumbs img {
		border-radius: 5px;
	}
	.custom-shop nav.woocommerce-breadcrumb {
		display: none;
	}
</style>
<?php
get_footer( 'shop' );

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
