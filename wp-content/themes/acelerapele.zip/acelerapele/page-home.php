<?php get_header(); ?>
		<?php echo do_shortcode('[home_banner]'); ?>
		<?php echo do_shortcode('[featured_infos]'); ?>
<section class="destaques">
	<?php echo do_shortcode('[all_cta]'); ?>
</section>
<!-- <section class="featured-trataments">
	<div class="container">
		<?php #echo do_shortcode('[product_carousel id="45" title="Confira nossos melhores tratamentos"]'); ?>
	</div>
</section> -->
<section class="sobre">
	<?php echo do_shortcode('[sobre]'); ?>
</section>
<section id="agendar-visita-banner">
<?php
	$title = get_field("agendar_online_banner_titulo",23);
	$image = get_field("agendar_online_banner_imagem",23);
	$title_button = get_field("agendar_online_botao_titulo",23);
	$link_button = get_field("agendar_online_botao_link",23);
	echo do_shortcode('[banner image="'. $image . '" title="'. $title . '" title_button="'. $title_button . '" link_button="'. $link_button . '"]'); 
?>
</section>
<section id="tratamentos">
<?php echo do_shortcode('[product_carousel id="50" title="tratamentos femininos" link="tratamento-categoria/feminino/"]'); ?>
	
<?php echo do_shortcode('[product_carousel id="56" title="tratamentos masculinos" link="tratamento-categoria/masculino/"]'); ?>
</section>
<section id="unidades">
	<div class="container">
		<h2 class="unidade-title">ENCONTRE UMA UNIDADE PERTO DE VOCÊ</h2>
		<div class="unidades">
			
		
		<?php if(have_rows("unidades",63)): while(have_rows("unidades",63)): the_row();?>
		<?php
			$title = get_sub_field("titulo",63);
			$infos = get_sub_field("informacoes",63);
			$mapa = get_sub_field("link_mapa",63);
			$zap = get_sub_field("link_whatsapp",63);
			$tel = get_sub_field("link_telefone",63);
			echo do_shortcode('[single_unidade title="'.$title.'" infos="'.$infos.'" zap="'.$zap.'" tel="'.$tel.'" mapa="'.$mapa.'"]'); 
		?>
		<?php endwhile; endif; ?>
		</div>
	</div>
</section>
<?php echo do_shortcode('[duvidas]'); ?>
<?php #echo do_shortcode('[areas_aplicacao]'); ?>

<?php
	$title = get_field("compre_seu_tratamento_titulo",23);
	$image = get_field("compre_seu_tratamento_imagem",23);
	$title_button = get_field("compre_seu_tratamento_titulo_botao",23);
	$link_button = get_field("compre_seu_tratamento_link_botao",23);
	echo do_shortcode('[banner image="'. $image . '" title="'. $title . '" title_button="'. $title_button . '" link_button="'. $link_button . '"]'); 
?>
<?php echo do_shortcode('[form_footer]'); ?>

<style>
	#unidades .container{
		display: flex;
		flex-wrap: wrap;
		flex-direction: column;
	}
	#unidades .unidades{
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
	}
	#tratamentos .qs:last-child .container .quem-somos-products{
		padding-top: 0 !important;
	}
	.featured-trataments{
		padding: 120px 0;
	}
	.product-carousel-2{
		padding-bottom: 160px;
		padding-top: 160px;
		background: #EAE8E6;
	}
	#agendar-visita-banner .overlay{
		background: #E1B261;
		opacity: 0.86;
	}
	#agendar-visita-banner p{
		margin-bottom: 0;
	}
	.unidade-title{
		text-align: center;
		color: #3C2300;
		text-transform: uppercase;
		font-size: 30px;
		margin-bottom: 45px;
	}
	#unidades{
		padding: 90px 0;
	}
	@media(max-width:767px){
		#unidades{
			padding-top: 45px;
			padding-bottom: 60px;
		}
		.unidade-title{
			font-size: 25px;
			text-align: center;
		}
	}
</style>
<?php get_footer(); ?>