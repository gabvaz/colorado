<?php
defined( 'ABSPATH' ) || exit;
?>

<style>
	@media(max-width:767px){
		.footer-menus-wrapper{
			flex-direction: column;
		}
		.footer-col{
			align-items: center;
		}
		.button-1{
			margin-top: 15px;
			margin-bottom: 20px;
		}
		.button-2,.button-1{
			min-width: 210px;
		}
		.button-2{
			margin-bottom: 80px !important;
		}
		.footer-title{
			margin-bottom: 40px;
		}
		.footer-menu{
			align-items: center;
			margin-bottom: 60px;
		}
		.agendar-treinamento{
			margin-bottom: 0;
		}
		.agendar-online{
			width: 240px;
			font-size: 16px;
			color: #3C2300;
			margin-bottom: 60px;
		}
		.payment-security{
			flex-direction: column;
			width: 100%;
		}
		.footer-payment-title{
			margin-bottom: 30px;
		}
		.footer-galery-1{
			display: flex !important;
			justify-content: space-between;
			grid-column-gap: 0;
		}
		.footer-galery-2{
			display: flex !important;
			justify-content: space-evenly;
			grid-column-gap: 0;
		}
		.single-payment-wrapper{
			width: 100%;
		}
		.footer-galery-1 div{
			width: 50px;
			height: 35px;
		}
		.footer-galery-1 img{
			width: 100%;
			height: 100%;
			object-fit: contain;
		}
		.footer-galery-1{
			margin-bottom: 45px;
		}
		.site-footer{
			padding: 30px 0;	
		}
		.site-footer .container{
			display: flex;
    		flex-direction: column;
    		align-items: center;
		}
		.payment-security{
			margin-top: 0 !important;
		}
		
		.copyright{
			width: 70%;
		}
	}
	.site-footer{
		background: #E9E2D4;
		padding: 65px 0;
	}
	.copyright {
		color: #3C2300;
		text-align: center;
	}
	.payment-security {
		display: flex;
		justify-content: space-around;
		align-items: center;
		text-align: center;
		margin-bottom: 70px;
		margin-top: 50px;
	}
	.footer-payment-title {
		color: #3C2300;
		font-size: 18px;
		margin-bottom: 20px;
	}
	.footer-galery-2 {
		display: grid;
		grid-template-columns: 1fr 1fr;
		grid-column-gap: 27px;
	}
	.footer-galery-1 {
		display: grid;
		grid-template-columns: repeat(6,1fr);
		grid-column-gap: 16px;
	}
	.footer-menus-wrapper{
		display: flex;
		justify-content: space-between;
	}
	.footer-col{
		display: flex;
		flex-direction: column;
	}
	.footer-title{
		color: #3C2300;
		font-size: 20px;
		margin-bottom: 23px;
	}
	.footer-menu {
		display: flex;
		flex-direction: column;
	}
	.footer-menu-link {
		color: #8E6730;
		font-size: 15px;
		margin-bottom: 19px;
	}
	.footer-menu-link-2 {
		color: #8E6730;
		font-size: 15px;
		margin-bottom: 13px;
	}
	.footer-button {
		background: #E1B261;
		text-align: center;
		border-radius: 5px;
		margin-top: 40px;
		padding: 13px 0px 10px;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.button-1 {
		padding-left: 15px;
		padding-right: 15px;
		color: white !important;
		font-size: 14px;
		background: #9A866C;
		margin-top: 19px;
		margin-bottom: 22px;
		justify-content: flex-start;
	}
	.button-2 {
		padding-left: 15px;
		padding-right: 15px;
		color: #3C2300;
		font-size: 14px;
		background: #E1CDB3;
		margin: 0;
		justify-content: flex-start;
	}
	.footer-button img{
		width: 22px;
		height: 22px;
		margin-right:11px;
	}
	.footer-galery-1 div {
    background: white;
    border-radius: 5px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 5px;
}
	.footer-button{
		cursor: pointer;
		color: #3C2300;
		
	}
	.footer-button:hover{
		color: #fff;
	}
	a.footer-menu-link:hover {
    	color: #3c231e;
}
</style>

<footer class="site-footer">
	<div class="container">
		<div class="footer-menus-wrapper">
			<div class="footer-col">
				<a href="/"><img style="width: 198px;" src="/wp-content/uploads/2021/09/logo-original.png"></a>
				<a href="tel:8131396001" class="footer-button button-1"> 
					<img src="/wp-content/uploads/2021/06/phone-call.png">
					LIGAR PARA AGENDAR
				</a>
				<a href="/contato" class="footer-button button-2">
					<img src="/wp-content/uploads/2021/06/operador-de-telemarketing.png">
					SOLICITAR CONTATO
				</a>
			</div>
			<div class="footer-col">
				<p class="footer-title">MENU</p>
				<div class="footer-menu">
					<a href="#" class="footer-menu-link">- SOBRE</a>
					<a href="#" class="footer-menu-link">- PROCEDIMENTOS</a>
					<a href="#" class="footer-menu-link">- UNIDADES</a>
					<a href="#" class="footer-menu-link">- CONTATO</a>
					<a href="#" class="footer-menu-link">- TRABALHE CONOSCO</a>
				</div>
			</div>
			<div class="footer-col">
				<p class="footer-title">AGENDAR TRATAMENTO</p>
				<div class="footer-menu agendar-treinamento">
					<a href="tel:8131396001" class="footer-menu-link-2">(81) 3139-6001 (RECIFE)</a>
					<a href="tel:8231941200" class="footer-menu-link-2">(82) 3194-1200 (MACEIÓ)</a>
<!-- 				<a href="tel:" class="footer-menu-link-2">(81) 99999-9999 (UNIDADE 03)</a> -->
				</div>
				<a href="https://api.whatsapp.com/send?phone=5581992591924&text=Quero%20saber%20mais%20sobre%20os%20tratamentos%20da%20cl%C3%ADnica%20pele!" target="_blank" class="footer-button agendar-online">AGENDAR-ONLINE</a>
			</div>
			<div class="footer-col">
				<p class="footer-title">UNIDADES</p>
				<div class="footer-menu">
					<a href="https://www.google.com/maps/place/Cl%C3%ADnica+Pele+Recife/@-8.1188563,-34.90636,17z/data=!3m1!4b1!4m5!3m4!1s0x7ab1fac60a765b9:0xbe59b7d28ef05c9e!8m2!3d-8.1188616!4d-34.9041713" class="footer-menu-link">- RECIFE - SHOPPING CENTER RECIFE</a>
					<a href="https://www.google.com/maps/place/Parque+Shopping+Macei%C3%B3/@-9.6276129,-35.7026688,17z/data=!3m1!5s0x701467f80dd8a33:0x5bed3d4d52a68f90!4m12!1m6!3m5!1s0x70145d56468dd03:0xc1384ef84ec6b8e1!2sCl%C3%ADnica+PELE!8m2!3d-9.6276129!4d-35.7004801!3m4!1s0x70145d57d34cfb3:0x288101b1bd399f0c!8m2!3d-9.6274793!4d-35.6989387" class="footer-menu-link">- MACEIÓ  - PARQUE SHOPPING MACEIÓ</a>
<!-- 					<a href="#" class="footer-menu-link">- UNIDADE 03</a> -->
				</div>
			</div>
		</div>
		<div class="payment-security">
			<div class="single-payment-wrapper">
				<p class="footer-payment-title">
					ACEITAMOS TODOS OS CARTÕES:
				</p>
				<div class="footer-galery-1">
					<div><img src="/wp-content/uploads/2021/06/Imagem-43.png"></div>
					<div><img src="/wp-content/uploads/2021/06/Imagem-44.png"></div>
					<div><img src="/wp-content/uploads/2021/06/Imagem-45.png"></div>
					<div><img src="/wp-content/uploads/2021/06/Imagem-46.png"></div>
					<div><img src="/wp-content/uploads/2021/06/Imagem-47.png"></div>
					<div><img src="/wp-content/uploads/2021/06/Imagem-48.png"></div>
				</div>
			</div>
<!-- 			<div class="single-payment-wrapper">
				<p class="footer-payment-title">
					SEGURANÇA:
				</p>
				<div class="footer-galery-2">
					<img src="/wp-content/uploads/2021/06/Grupo-2102.png">
					<img src="/wp-content/uploads/2021/06/Grupo-2103.png">
				</div>
			</div> -->
		</div>
		<div class="copyright">
			Copyright@2021 ACELERE PELE. Todos os direitos reservados.
		</div>
	</div>
</footer>



</div><!-- #page we need this extra closing tag here -->

<?php wp_footer(); ?>

</body>

</html>

