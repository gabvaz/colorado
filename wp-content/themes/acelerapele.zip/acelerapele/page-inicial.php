<?php
defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php wp_head(); ?>
	</head>
	<style>
		@font-face {
			font-family: "Neon80s";
			src: url("/wp-content/themes/acelerapele/fonts/Neon.ttf");
		}
		html{
			margin-top: 0 !important;
		}
		*{
		  font-family: Neon80s !important;
		}
		.qtd {
			font-size: 11px;
			color: #211304;
			font-weight: lighter;
			margin-left: 10px;
			min-height: 16px;
			min-width: 1px;
			margin-bottom: 30px;
		}
		.cart-count-{
			font-size: 10px;
		}
		header span.woocommerce-Price-amount.amount {
			font-size: 15px;	
		}

		.summary .fswp_installments_price.single {
    display: none;
}
		span.fswp_installment_prefix {
    display: block;
    text-align: left;
    padding-left: 10px;
    font-size: 11px;
    color: #211304;
}
		ul.products.columns-3 span.price {
			display: none !important;
		}
		p.price.fswp_calc {
			display: flex !important;
			align-items: center;
			flex-direction: column;
			align-items: flex-start;
		}
 		.agendar-online-btn{
			position: fixed;
			top: 325px;
			right: -50px;
			z-index: 10;
			background: #F8955E;
			border-radius: 0px 0px 5px 5px;
			border: 0;
			padding: 10px 10px;
			transform: rotate(90deg) translatex(-50%);
			width: 150px;
			height: 50px;
			text-align: center;
		}
		a .agendar-online-btn{
			color: #FFFFFF;
			font-size: 14px;
		} 
		.agendar-online-div a:hover{
			background: #F8955E;
			opacity: 1;
		}
		.header-actions-wrapper-mobile{
			display: none;
		}
		.logo-link:hover{
			opacity: 1;
		}

		@media(max-width:767px){
			.agendar-online-btn{
				display: none;
			}
			.header-actions-wrapper-mobile{
				display: flex;
				width: 100%;
				position: fixed;
				bottom: 0;
				left: 0;
				z-index: 10;
			}
			.header-actions-wrapper-mobile .shop-mobile{
				text-transform: uppercase;
				background: #58B76B;
				font-size: 14px;
				text-align: center;
				width: 50%;
				color: #ffffff;
				padding: 15px 0;
			}

			.header-actions-wrapper-mobile .agendar-mobile{
				text-transform: uppercase;
				background: #E1B261;
				color: #3C2300;
				font-size: 14px;
				text-align: center;
				width: 50%;
				padding: 15px 0;
			}
		}
	</style>
	<body <?php body_class(); ?>>
		<section class="bg">
<section id="page-initial">
	<div class="logo-text">
		<a href="/home">
			<img src="/wp-content/uploads/2021/09/logo-original.png">
		</a>
		<h2>
			eSCOLHA A CIDADE:
		</h2>
	</div>
	<div class="escolha-cidade">
		<?php if(have_rows("cidades")): while(have_rows("cidades")): the_row(); ?>
		<div class="cidade" style="background: url('<?php the_sub_field("imagem");?>')">
			<a href="<?php the_sub_field("link");?>">
				<div class="cta-overlay"></div>
				<button>
					<?php the_sub_field("cidade");?>
				</button>
			</a>
		</div>
		<?php endwhile; endif; ?>
		
	</div>
</section>
</section>	
	</body>
</html>
		
		
		
<style>
	.bg{
		background: #E9E2D4;
		width: 100%;
		height: 100vh;
	}
	.cta-overlay {
		position: absolute;
		width: 100%;
		height: 100%;
		background: #9A866C;
		opacity: 0.85;
		top: 0;
		left: 0;
		border-radius: 5px;
		z-index: -1;
	}
	#page-initial{
		background: url('/wp-content/uploads/2021/06/background-home-1.png');
		background-repeat: repeat;
		height: 100%;
	}
	#page-initial .logo-text{
		display: flex;
		flex-direction: column;
		align-items: center;
	}
	#page-initial .logo-text a{
		margin-top: 80px;
		margin-bottom: 25px;
	}
	#page-initial .logo-text h2{
		font-size: 30px;
		color: #3C2300;
		text-transform: uppercase;
	}
	#page-initial .escolha-cidade{
		margin-top: 60px;
		display: grid;
		grid-template-columns: 1fr 1fr 1fr;
		grid-column-gap: 45px;
		margin-left: 15px;
		margin-right: 15px;
	}
	#page-initial .escolha-cidade .cidade{
		width: 100%;
		height: 215px;
		display: flex;
		justify-content: center;
		align-items: center;
		position: relative;
		z-index: 2;
	}
	#page-initial .escolha-cidade .cidade a button{
		font-size: 25px;
		width: 215px;
		height: 60px;
		border: 2px solid #FFFFFF;
		border-radius: 5px;
		background: transparent;
		color: #ffffff;
		cursor: pointer;
	}
</style>



